
#Author: Carlos Martinez
#Date: 7/8/2019

#Select First Drive #

#MDT Task Sequence enviroment object
$TSEnv = New-Object -COMObject Microsoft.SMS.TSEnvironment

#Get First Drive index number from the system 
$DriveIndex = Get-PhysicalDisk | Where-Object { $_.MediaType -eq "SSD" -or $_.MediaType -eq "HDD" } | Select-Object -First 1
$DriveIndex =  $DriveIndex.DeviceId

#Assign the first drive index to the MDT Task Sequence enviroment variable 'OSDDiskIndex'
$TSEnv.Value('OSDDiskIndex') = $DriveIndex

